// -------------------- GLOBAL --------------------
let cart = JSON.parse(localStorage.getItem("cart")) || [];
let isLoggedIn = JSON.parse(localStorage.getItem("loggedIn")) || false;

// -------------------- LOGIN / LOGOUT HANDLING --------------------
function logout() {
  localStorage.removeItem("cart"); // Clear the cart
  localStorage.setItem("loggedIn", false); // Update login status
  updateCartCount(); // Reset cart count
  alert("Logged out successfully. Your cart has been cleared.");
  window.location.href = "login.html"; // Redirect to login page
}


// -------------------- CART FUNCTIONS --------------------
function updateCartCount() {
  const count = document.getElementById("cart-count");
  if (count) count.textContent = cart.length;
}

function addToCart(title, price) {
  cart.push({ title, price });
  localStorage.setItem("cart", JSON.stringify(cart));
  updateCartCount();
  alert(`${title} added to cart!`);
}
function removeFromCart(index) {
  const removedItem = cart.splice(index, 1)[0];
  localStorage.setItem("cart", JSON.stringify(cart));
  renderCart();
  updateCartCount();
  alert(`${removedItem.title} removed from cart.`);
}
// -------------------- RENDER BOOKS --------------------
function renderBooks(data, heading = "Books") {
  const container = document.getElementById("books-container");
  const title = document.querySelector(".book-list h2");
  if (!container || !title) return;

  title.textContent = heading;
  container.innerHTML = "";

  data.forEach((book, index) => {
    const bookDiv = document.createElement("div");
    bookDiv.classList.add("book");
    bookDiv.innerHTML = `
      <img src="${book.img}" alt="${book.title}">
      <h3>${book.title}</h3>
      <p>Author: ${book.author}</p>
      <p>₹${book.price}</p>
      <button onclick='addToCart("${book.title}", ${book.price})'>Add to Cart</button>
    `;
    container.appendChild(bookDiv);
  });
}

// -------------------- RENDER CART --------------------
function renderCart() {
  const cartContainer = document.getElementById("cart-items");
  if (!cartContainer) return;

  cartContainer.innerHTML = "";
  let total = 0;

  cart.forEach((item, index) => {
    total += item.price;
    const itemDiv = document.createElement("div");
    itemDiv.classList.add("cart-item");
    <button onclick="removeFromCart(${index})">Remove</button>
    itemDiv.innerHTML = `
      <p><strong>${item.title}</strong> - ₹${item.price}</p>
      <button onclick="removeFromCart(${index})">Remove</button>
    `;
    cartContainer.appendChild(itemDiv);
  });

  cartContainer.innerHTML += `
    <hr />
    <p><strong>Total Books:</strong> ${cart.length}</p>
    <p><strong>Total Price:</strong> ₹${total}</p>
  `;
}

// -------------------- BOOK LIST DATA --------------------
const popularBooks = [
  { title: "The Alchemist", author: "Paulo Coelho", price: 349, img: "images/book1.jpg" },
  { title: "Wings of Fire", author: "A.P.J Abdul Kalam", price: 199, img: "images/book2.jpg" },
  { title: "Think Like a Monk", author: "Jay Shetty", price: 299, img: "images/book3.jpg" },
  { title: "Rich Dad Poor Dad", author: "Robert Kiyosaki", price: 279, img: "images/book4.jpg" },
  { title: "Atomic Habits", author: "James Clear", price: 450, img: "images/book5.jpg" },
  { title: "IKIGAI", author: "Francesc Miralles", price: 249, img: "images/book6.jpg" },
  { title: "The Power of Subconscious Mind", author: "Joseph Murphy", price: 299, img: "images/book7.jpg" },
  { title: "Life’s Amazing Secrets", author: "Gaur Gopal Das", price: 325, img: "images/book8.jpg" }
];

const allBooks = Array.from({ length: 25 }, (_, i) => ({
  title: `Book Title ${i + 1}`,
  author: `Author ${i + 1}`,
  price: Math.floor(Math.random() * 500) + 100,
  img: `https://via.placeholder.com/200x250?text=Book+${i + 1}`
}));

// -------------------- DOM READY --------------------
document.addEventListener("DOMContentLoaded", () => {
  updateCartCount();

  // Render popular books on home load
  if (document.getElementById("books-container")) {
    renderBooks(popularBooks, "Popular Books");
  }

  // If it's the cart page
  if (document.getElementById("cart-items")) {
    renderCart();
  }

  // Handle nav buttons
  const homeBtn = document.getElementById("home-link");
  const bookBtn = document.getElementById("books-link");

  if (homeBtn) homeBtn.addEventListener("click", () => renderBooks(popularBooks, "Popular Books"));
  if (bookBtn) bookBtn.addEventListener("click", () => renderBooks(allBooks, "All Books"));
});
function searchBooks() {
  const input = document.getElementById("searchInput").value.toLowerCase();
  const books = document.querySelectorAll(".book");
  let found = false;

  books.forEach(book => {
    const title = book.querySelector("h3").textContent.toLowerCase();
    if (title.includes(input)) {
      book.style.display = "inline-block";
      found = true;
    } else {
      book.style.display = "none";
    }
  });

  if (!found) {
    alert("No books found!");
  }
}