const express = require("express");
const app = express();
const cors = require("cors");
const bodyParser = require("body-parser");

app.use(cors());
app.use(bodyParser.json());
app.use(express.static("../your-frontend-folder")); // Adjust path if needed

let books = [
  { id: 1, title: "The Alchemist", author: "Paulo Coelho", price: 349 },
  { id: 2, title: "Wings of Fire", author: "A.P.J Abdul Kalam", price: 199 },
  { id: 3, title: "Think Like a Monk", author: "Jay Shetty", price: 299 },
  { id: 4, title: "Rich Dad Poor Dad", author: "Robert Kiyosaki", price: 279 },
  { id: 5, title: "Atomic Habits", author: "James Clear", price: 450 },
  { id: 6, title: "IKIGAI", author: "Francesc Miralles", price: 249 },
  { id: 7, title: "The Power of Your Subconscious Mind", author: "Joseph Murphy", price: 299 },
  { id: 8, title: "Life's Amazing Secrets", author: "Gaur Gopal Das", price: 325 },
  { id: 9, title: "Book Title Two", author: "Jane Smith", price: 399 }
];

let cart = [];

app.get("/api/books", (req, res) => {
  res.json(books);
});

app.get("/api/cart", (req, res) => {
  res.json(cart);
});

app.post("/api/cart/add", (req, res) => {
  const { title, price } = req.body;
  cart.push({ title, price });
  res.json({ message: "Book added to cart", cart });
});

app.post("/api/login", (req, res) => {
  const { username, password } = req.body;
  if (username === "admin" && password === "1234") {
    res.json({ success: true, message: "Login successful" });
  } else {
    res.status(401).json({ success: false, message: "Invalid credentials" });
  }
});

const PORT = 3000;
app.listen(PORT, () => {
  console.log(`✅ Server running on http://localhost:{2323}`);
});