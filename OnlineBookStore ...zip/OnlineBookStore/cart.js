const express = require("express");
const router = express.Router();
const db = require("../models/dbInit");

// Delete item from cart by bookId (and optional userId)
router.delete("/:userId/:bookId", (req, res) => {
  const { userId, bookId } = req.params;

  db.run(
    "DELETE FROM cart WHERE userId = ? AND bookId = ?",
    [userId, bookId],
    function (err) {
      if (err) {
        return res.status(500).json({ error: err.message });
      }
      res.json({ message: "Book removed from cart", changes: this.changes });
    }
  );
});
module.exports = router;